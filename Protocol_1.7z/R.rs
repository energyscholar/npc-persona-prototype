/// Relational cost / effort observable
/// 
/// R measures how much imposed constraint is required
/// to maintain the current system state.
/// 
/// IMPORTANT:
/// - R is NOT a control parameter
/// - R is NOT fed back into the engine
/// - R is read-only outside the core
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct RelationalCost {
    /// Aggregate magnitude of constraint conflict
    value: f64,
}

impl RelationalCost {
    /// Create a new R value from internal computation only
    pub(crate) fn new(value: f64) -> Self {
        Self { value }
    }

    /// Read-only access for diagnostics, tests, and visualization
    pub fn value(&self) -> f64 {
        self.value
    }
}
