//! # B Operator: Coherence Accumulation
//!
//! ## Mathematical Definition
//! ```text
//! B(x)[i] = x[i] + x[(i+1) mod n]
//! ```
//!
//! ## Operator Type
//! **Unary field operator with periodic boundaries**: Takes a vector, returns a vector of equal length.
//!
//! ## Guaranteed Properties
//! 1. **Length-preserving**: len(B(x)) = len(x) always
//! 2. **Linear**: B(αx + βy) = αB(x) + βB(y)
//! 3. **Circular**: Last element wraps to first (periodic boundary)
//! 4. **Sum-preserving**: Σ B(x)[i] = 2·Σ x[i] (each element counted twice)
//!
//! ## Physical Interpretation
//! B integrates each element with its circular neighbor, building **local coherence**
//! while preserving global field structure. This reveals:
//! - Communication patterns between adjacent entities
//! - Local accumulation dynamics
//! - Neighbor-to-neighbor interactions
//!
//! ## Relational Semantics
//! B operates on **relational gradients** (typically output of A):
//! - Input: Gradient field from A operator
//! - Output: Accumulated pattern field
//! - Meaning: "How do adjacent imbalances combine?"
//!
//! ## Examples
//! ```text
//! B([1, 2, 4]) = [1+2, 2+4, 4+1] = [3, 6, 5]
//! B([1, -1, 1, -1]) = [0, 0, 0, 0]  // alternating cancels
//! B([5, 5, 5]) = [10, 10, 10]       // uniform doubles
//! ```

#![allow(non_snake_case)]

/// B Operator: Circular neighbor accumulation
///
/// Each output element is the sum of the input element and its next neighbor,
/// with periodic boundary conditions (last wraps to first).
///
/// # Mathematical Form
/// ```text
/// B(x)[i] = x[i] + x[(i+1) mod n]
/// ```
///
/// # Arguments
/// * `field` - Input relational field (vector of f64)
///
/// # Returns
/// Accumulated field with same length as input
///
/// # Guarantees
/// - **Linearity**: B(αx + βy) = αB(x) + βB(y)
/// - **Length preservation**: len(B(x)) = len(x)
/// - **Circularity**: Element n-1 adds element 0
///
/// # Examples
/// ```
/// use operator_core::B;
///
/// let field = vec![1.0, 2.0, 4.0];
/// let accumulated = B(&field);
/// 
/// // [1+2, 2+4, 4+1] = [3.0, 6.0, 5.0]
/// assert!((accumulated[0] - 3.0).abs() < 1e-10);
/// assert!((accumulated[1] - 6.0).abs() < 1e-10);
/// assert!((accumulated[2] - 5.0).abs() < 1e-10);
/// ```
///
/// # Edge Cases
/// - Empty field returns empty vector
/// - Single element returns [2*element] (wraps to itself)
pub fn B(field: &[f64]) -> Vec<f64> {
    if field.is_empty() {
        return Vec::new();
    }

    let n = field.len();
    
    field.iter()
        .enumerate()
        .map(|(i, &x)| {
            let next_i = (i + 1) % n;
            x + field[next_i]
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_length_preservation() {
        let field = vec![1.0, 2.0, 3.0, 4.0];
        let result = B(&field);
        
        assert_eq!(result.len(), field.len(),
            "B must preserve field length");
    }

    #[test]
    fn test_circular_neighbor_sum() {
        let field = vec![1.0, 2.0, 4.0];
        let result = B(&field);
        
        // [1+2, 2+4, 4+1] = [3, 6, 5]
        assert!((result[0] - 3.0).abs() < 1e-10);
        assert!((result[1] - 6.0).abs() < 1e-10);
        assert!((result[2] - 5.0).abs() < 1e-10);
    }

    #[test]
    fn test_empty_field() {
        let field: Vec<f64> = vec![];
        let result = B(&field);
        
        assert!(result.is_empty());
    }

    #[test]
    fn test_single_element() {
        let field = vec![5.0];
        let result = B(&field);
        
        // Wraps to itself: 5 + 5 = 10
        assert_eq!(result.len(), 1);
        assert!((result[0] - 10.0).abs() < 1e-10);
    }

    #[test]
    fn test_two_elements() {
        let field = vec![3.0, 7.0];
        let result = B(&field);
        
        // [3+7, 7+3] = [10, 10]
        assert_eq!(result.len(), 2);
        assert!((result[0] - 10.0).abs() < 1e-10);
        assert!((result[1] - 10.0).abs() < 1e-10);
    }

    #[test]
    fn test_linearity_scalar() {
        let field = vec![1.0, 2.0, 3.0, 4.0];
        let alpha = 2.5;
        
        // B(αx)
        let scaled_field: Vec<f64> = field.iter().map(|&x| alpha * x).collect();
        let b_scaled = B(&scaled_field);
        
        // αB(x)
        let b_original = B(&field);
        let alpha_b: Vec<f64> = b_original.iter().map(|&x| alpha * x).collect();
        
        // Should be equal
        for (a, b) in b_scaled.iter().zip(alpha_b.iter()) {
            assert!((a - b).abs() < 1e-10,
                "Linearity violated: B(αx) ≠ αB(x)");
        }
    }

    #[test]
    fn test_linearity_addition() {
        let x = vec![1.0, 2.0, 3.0, 4.0];
        let y = vec![5.0, 6.0, 7.0, 8.0];
        
        // B(x + y)
        let sum: Vec<f64> = x.iter().zip(y.iter()).map(|(&a, &b)| a + b).collect();
        let b_sum = B(&sum);
        
        // B(x) + B(y)
        let b_x = B(&x);
        let b_y = B(&y);
        let sum_b: Vec<f64> = b_x.iter().zip(b_y.iter()).map(|(&a, &b)| a + b).collect();
        
        // Should be equal
        for (a, b) in b_sum.iter().zip(sum_b.iter()) {
            assert!((a - b).abs() < 1e-10,
                "Linearity violated: B(x+y) ≠ B(x)+B(y)");
        }
    }

    #[test]
    fn test_negative_values() {
        let field = vec![-1.0, 2.0, -3.0, 4.0];
        let result = B(&field);
        
        // [-1+2, 2+(-3), -3+4, 4+(-1)] = [1, -1, 1, 3]
        assert!((result[0] - 1.0).abs() < 1e-10);
        assert!((result[1] - (-1.0)).abs() < 1e-10);
        assert!((result[2] - 1.0).abs() < 1e-10);
        assert!((result[3] - 3.0).abs() < 1e-10);
    }

    #[test]
    fn test_alternating_field() {
        let field = vec![1.0, -1.0, 1.0, -1.0];
        let result = B(&field);
        
        // [1+(-1), -1+1, 1+(-1), -1+1] = [0, 0, 0, 0]
        assert!(result.iter().all(|&x| x.abs() < 1e-10),
            "Alternating field should sum to zero");
    }

    #[test]
    fn test_large_field() {
        let field: Vec<f64> = (0..10000).map(|i| i as f64).collect();
        let result = B(&field);
        
        assert_eq!(result.len(), 10000);
        // First element: 0 + 1 = 1
        assert!((result[0] - 1.0).abs() < 1e-10);
        // Last element wraps: 9999 + 0 = 9999
        assert!((result[9999] - 9999.0).abs() < 1e-6);
    }

    #[test]
    fn test_zero_field() {
        let field = vec![0.0, 0.0, 0.0, 0.0];
        let result = B(&field);
        
        assert!(result.iter().all(|&x| x.abs() < 1e-10),
            "B of zero field should be zero");
    }

    #[test]
    fn test_uniform_field_doubles() {
        let field = vec![5.0, 5.0, 5.0];
        let result = B(&field);
        
        // Each element: 5 + 5 = 10
        assert!(result.iter().all(|&x| (x - 10.0).abs() < 1e-10),
            "Uniform field should double under B");
    }

    #[test]
    fn test_sum_preservation() {
        let field = vec![1.0, 2.0, 3.0, 4.0, 5.0];
        let result = B(&field);
        
        let input_sum: f64 = field.iter().sum();
        let output_sum: f64 = result.iter().sum();
        
        // Each element counted twice, so output sum = 2 * input sum
        assert!((output_sum - 2.0 * input_sum).abs() < 1e-10,
            "Sum preservation violated");
    }
}
