//! # A Operator: Relational Gradient Extraction
//!
//! ## Mathematical Definition
//! ```text
//! A(x)[i] = x[i] - mean(x)
//! 
//! where mean(x) = (Σ x[i]) / n
//! ```
//!
//! ## Operator Type
//! **Unary field operator**: Takes a vector, returns a vector of equal length.
//!
//! ## Guaranteed Properties
//! 1. **Zero-sum**: Σ A(x)[i] = 0 (algebraically guaranteed)
//! 2. **Structure-preserving**: |A(x)[i]| ≤ max(|x[i]|)
//! 3. **Length-preserving**: len(A(x)) = len(x)
//! 4. **Translation-invariant**: A(x + c) = A(x) for any constant c
//!
//! ## Physical Interpretation
//! A extracts **relational gradients** by measuring each element's deviation
//! from the field's mean. This reveals:
//! - Which elements are above/below the collective average
//! - The magnitude of local imbalances
//! - Relational boundaries within the field
//!
//! ## Relational Semantics
//! A operates on a **relational field** (not individual objects):
//! - Input: Numerical sequence representing system state
//! - Output: Gradient field showing deviations from equilibrium
//! - Meaning: "How does each value relate to the collective center?"
//!
//! ## Examples
//! ```text
//! A([1, 2, 3]) = [-1, 0, 1]        // mean = 2
//! A([5, 5, 5]) = [0, 0, 0]         // uniform field
//! A([10, 20, 30, 40]) = [-15, -5, 5, 15]  // mean = 25
//! ```

#![allow(non_snake_case)]

/// A Operator: Extract relational gradients from field
///
/// Computes deviation of each element from the mean of the entire field.
/// This operation is **guaranteed** to produce zero-sum output.
///
/// # Mathematical Form
/// ```text
/// A(x)[i] = x[i] - μ
/// where μ = (Σ x[i]) / n
/// ```
///
/// # Arguments
/// * `field` - Input relational field (vector of f64)
///
/// # Returns
/// Gradient field where each element represents deviation from mean
///
/// # Guarantees
/// - **Zero-sum**: Σ A(x)[i] = 0 (exact, within floating-point precision)
/// - **Length preservation**: len(A(x)) = len(x)
/// - **No amplification**: max(|A(x)|) ≤ max(|x|)
///
/// # Examples
/// ```
/// use operator_core::A;
///
/// let field = vec![1.0, 2.0, 3.0];
/// let gradients = A(&field);
/// 
/// // mean = 2.0, so gradients = [-1.0, 0.0, 1.0]
/// assert!((gradients[0] + 1.0).abs() < 1e-10);
/// assert!((gradients[1]).abs() < 1e-10);
/// assert!((gradients[2] - 1.0).abs() < 1e-10);
///
/// // Zero-sum guaranteed
/// let sum: f64 = gradients.iter().sum();
/// assert!(sum.abs() < 1e-10);
/// ```
///
/// # Edge Cases
/// - Empty field returns empty vector
/// - Single element returns [0.0] (deviation from itself)
/// - Uniform field returns all zeros
pub fn A(field: &[f64]) -> Vec<f64> {
    if field.is_empty() {
        return Vec::new();
    }

    // Single element has zero gradient (deviation from itself)
    if field.len() == 1 {
        return vec![0.0];
    }

    // Calculate mean: μ = (Σ x_i) / n
    let mean = field.iter().sum::<f64>() / field.len() as f64;

    // Compute gradients: ∇_i = x_i - μ
    // Zero-sum is GUARANTEED by this algebraic form:
    // Σ(x_i - μ) = Σx_i - n·μ = Σx_i - n·(Σx_i/n) = Σx_i - Σx_i = 0
    field.iter()
        .map(|&x| x - mean)
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_zero_sum_property() {
        let field = vec![1.0, 2.0, 3.0, 4.0, 5.0];
        let gradients = A(&field);
        
        let sum: f64 = gradients.iter().sum();
        assert!(sum.abs() < 1e-10, 
            "Zero-sum property violated: sum = {}", sum);
    }

    #[test]
    fn test_empty_field() {
        let field: Vec<f64> = vec![];
        let gradients = A(&field);
        
        assert!(gradients.is_empty());
    }

    #[test]
    fn test_single_element() {
        let field = vec![42.0];
        let gradients = A(&field);
        
        assert_eq!(gradients.len(), 1);
        assert!((gradients[0]).abs() < 1e-10, 
            "Single element should have zero gradient");
    }

    #[test]
    fn test_uniform_field() {
        let field = vec![5.0, 5.0, 5.0, 5.0];
        let gradients = A(&field);
        
        assert!(gradients.iter().all(|&g| g.abs() < 1e-10),
            "Uniform field should have zero gradients");
    }

    #[test]
    fn test_simple_case() {
        let field = vec![1.0, 2.0, 3.0];
        let gradients = A(&field);
        
        // mean = 2.0
        // expected: [1.0 - 2.0, 2.0 - 2.0, 3.0 - 2.0] = [-1.0, 0.0, 1.0]
        assert!((gradients[0] - (-1.0)).abs() < 1e-10);
        assert!((gradients[1] - 0.0).abs() < 1e-10);
        assert!((gradients[2] - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_length_preservation() {
        let field = vec![1.0, 2.0, 3.0, 4.0, 5.0];
        let gradients = A(&field);
        
        assert_eq!(gradients.len(), field.len(),
            "A operator must preserve field length");
    }

    #[test]
    fn test_translation_invariance() {
        let field = vec![1.0, 2.0, 3.0, 4.0];
        let shifted_field: Vec<f64> = field.iter().map(|&x| x + 100.0).collect();
        
        let grad1 = A(&field);
        let grad2 = A(&shifted_field);
        
        // A(x + c) = A(x)
        for (g1, g2) in grad1.iter().zip(grad2.iter()) {
            assert!((g1 - g2).abs() < 1e-10,
                "Translation invariance violated");
        }
    }

    #[test]
    fn test_large_field() {
        let field: Vec<f64> = (0..10000).map(|i| i as f64).collect();
        let gradients = A(&field);
        
        let sum: f64 = gradients.iter().sum();
        assert!(sum.abs() < 1e-6, 
            "Zero-sum must hold for large fields: sum = {}", sum);
    }

    #[test]
    fn test_negative_values() {
        let field = vec![-3.0, -1.0, 1.0, 3.0];
        let gradients = A(&field);
        
        let sum: f64 = gradients.iter().sum();
        assert!(sum.abs() < 1e-10,
            "Zero-sum must hold for negative values");
    }

    #[test]
    fn test_mixed_magnitudes() {
        let field = vec![0.001, 1000.0, -500.0, 0.0];
        let gradients = A(&field);
        
        let sum: f64 = gradients.iter().sum();
        assert!(sum.abs() < 1e-6,
            "Zero-sum must hold across magnitude ranges");
    }

    #[test]
    fn test_no_amplification() {
        let field = vec![10.0, -5.0, 3.0, -8.0];
        let gradients = A(&field);
        
        let max_input = field.iter().map(|x| x.abs()).fold(0.0, f64::max);
        let max_output = gradients.iter().map(|x| x.abs()).fold(0.0, f64::max);
        
        assert!(max_output <= max_input,
            "A should not amplify: max_out = {}, max_in = {}", max_output, max_input);
    }
}
