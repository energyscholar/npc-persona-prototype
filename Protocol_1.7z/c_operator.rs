//! # C Operator: Collapse/Stability
//!
//! ## Mathematical Definition
//! ```text
//! C(x)[i] = x[i] / (1 + |x[i]|)
//! ```
//!
//! ## Operator Type
//! **Unary contraction mapping**: Takes a vector, returns a vector of equal length with bounded values.
//!
//! ## Guaranteed Properties
//! 1. **Bounded**: -1 ≤ C(x)[i] ≤ 1 (mathematically proven for all real x)
//! 2. **Contraction**: |C(x)[i]| ≤ |x[i]| (non-expansive)
//! 3. **Length-preserving**: len(C(x)) = len(x)
//! 4. **Sign-preserving**: sign(C(x)[i]) = sign(x[i])
//! 5. **Monotonic**: If |x| < |y|, then |C(x)| < |C(y)|
//!
//! ## Physical Interpretation
//! C collapses field values into stable, bounded states through a contraction mapping.
//! This represents:
//! - Stabilization of unbounded dynamics
//! - Saturation effects (diminishing returns)
//! - Final equilibrium state
//!
//! ## Relational Semantics
//! C operates on **accumulated patterns** (typically output of B):
//! - Input: Unbounded accumulated field
//! - Output: Bounded stable field in [-1, 1]
//! - Meaning: "What is the stable relational configuration?"
//!
//! ## Mathematical Proof of Bounds
//! For x > 0:
//!   C(x) = x/(1+x) < x/x = 1  ✓
//! 
//! For x < 0:
//!   C(x) = x/(1-x) > x/x = -1 for x < 0  ✓
//!
//! For x = 0:
//!   C(0) = 0/(1+0) = 0  ✓
//!
//! ## Examples
//! ```text
//! C([0]) = [0]
//! C([1]) = [0.5]
//! C([10]) ≈ [0.91]
//! C([100]) ≈ [0.99]
//! C([-1]) = [-0.5]
//! C([-10]) ≈ [-0.91]
//! ```

#![allow(non_snake_case)]

/// C Operator: Unary contraction to bounded state
///
/// Applies element-wise contraction that **guarantees** output bounds of [-1, 1].
/// This is a mathematical certainty, not a numerical approximation.
///
/// # Mathematical Form
/// ```text
/// C(x)[i] = x[i] / (1 + |x[i]|)
/// ```
///
/// # Arguments
/// * `field` - Input relational field (vector of f64)
///
/// # Returns
/// Collapsed field with guaranteed bounds [-1, 1]
///
/// # Guarantees
/// - **Bounds**: -1 ≤ C(x)[i] ≤ 1 for all x ∈ ℝ
/// - **Contraction**: |C(x)[i]| ≤ |x[i]|
/// - **Sign preservation**: sign(C(x)[i]) = sign(x[i])
///
/// # Examples
/// ```
/// use operator_core::C;
///
/// let field = vec![2.0, -4.0, 0.5, 0.0];
/// let collapsed = C(&field);
///
/// // All results guaranteed in [-1, 1]
/// assert!(collapsed.iter().all(|&v| v >= -1.0 && v <= 1.0));
///
/// // Verify specific values
/// assert!((collapsed[0] - 2.0/3.0).abs() < 1e-10);  // 2/(1+2)
/// assert!((collapsed[1] - (-0.8)).abs() < 1e-10);   // -4/(1+4)
/// ```
///
/// # Edge Cases
/// - Empty field returns empty vector
/// - Zero values remain zero
/// - Very large |x| → C(x) approaches ±1
pub fn C(field: &[f64]) -> Vec<f64> {
    if field.is_empty() {
        return Vec::new();
    }
    
    field.iter()
        .map(|&x| {
            // C(x) = x / (1 + |x|)
            // Mathematically guaranteed: |result| ≤ 1
            // Proof: For x > 0: x/(1+x) < 1
            //        For x < 0: x/(1-x) > -1
            x / (1.0 + x.abs())
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_length_preservation() {
        let field = vec![1.0, -5.0, 0.2, 10.0];
        let result = C(&field);
        
        assert_eq!(result.len(), field.len(),
            "C must preserve field length");
    }

    #[test]
    fn test_bounds_property() {
        let field = vec![100.0, -50.0, 0.0, 5.0, -1000.0, 0.001];
        let result = C(&field);
        
        for &value in &result {
            assert!(value >= -1.0 && value <= 1.0,
                "Bounds violated: value = {}", value);
        }
    }

    #[test]
    fn test_empty_field() {
        let field: Vec<f64> = vec![];
        let result = C(&field);
        
        assert!(result.is_empty());
    }

    #[test]
    fn test_simple_cases() {
        // C(0) = 0/(1+0) = 0
        let zero = C(&vec![0.0]);
        assert!((zero[0]).abs() < 1e-10);
        
        // C(1) = 1/(1+1) = 0.5
        let one = C(&vec![1.0]);
        assert!((one[0] - 0.5).abs() < 1e-10);
        
        // C(-1) = -1/(1+1) = -0.5
        let neg_one = C(&vec![-1.0]);
        assert!((neg_one[0] - (-0.5)).abs() < 1e-10);
        
        // C(2) = 2/(1+2) = 2/3
        let two = C(&vec![2.0]);
        assert!((two[0] - (2.0/3.0)).abs() < 1e-10);
    }

    #[test]
    fn test_contraction_property() {
        let field = vec![2.0, -3.0, 10.0, 0.5, -100.0];
        let result = C(&field);
        
        // |C(x)| ≤ |x| for all x
        for (x, c_x) in field.iter().zip(result.iter()) {
            assert!(c_x.abs() <= x.abs(),
                "Contraction violated: |C({})| = {} > {}", x, c_x.abs(), x.abs());
        }
    }

    #[test]
    fn test_extreme_values() {
        let field = vec![1e10, -1e10, 1e100, -1e100];
        let result = C(&field);
        
        // Even with extreme inputs, output must be bounded
        for &value in &result {
            assert!(value.abs() <= 1.0,
                "Bounds violated with extreme input: {}", value);
        }
        
        // For very large |x|, C(x) → ±1
        assert!((result[0] - 1.0).abs() < 1e-6);
        assert!((result[1] - (-1.0)).abs() < 1e-6);
    }

    #[test]
    fn test_zero_inputs() {
        let field = vec![0.0, 0.0, 0.0];
        let result = C(&field);
        
        // C(0) = 0
        assert!(result.iter().all(|&x| x.abs() < 1e-10));
    }

    #[test]
    fn test_small_values() {
        let field = vec![0.1, -0.05, 0.001];
        let result = C(&field);
        
        // For small x, C(x) ≈ x
        for (x, c_x) in field.iter().zip(result.iter()) {
            assert!((x - c_x).abs() < 0.01,
                "Small value approximation failed: C({}) = {}", x, c_x);
        }
    }

    #[test]
    fn test_large_field() {
        let field: Vec<f64> = (0..10000).map(|i| (i as f64 - 5000.0) / 100.0).collect();
        let result = C(&field);
        
        assert_eq!(result.len(), 10000);
        assert!(result.iter().all(|&x| x.abs() <= 1.0));
    }

    #[test]
    fn test_negative_values() {
        let field = vec![-1.0, -2.0, -10.0, -0.5];
        let result = C(&field);
        
        // All should be negative and bounded
        assert!(result.iter().all(|&x| x < 0.0 && x >= -1.0));
    }

    #[test]
    fn test_positive_values() {
        let field = vec![1.0, 2.0, 10.0, 0.5];
        let result = C(&field);
        
        // All should be positive and bounded
        assert!(result.iter().all(|&x| x > 0.0 && x <= 1.0));
    }

    #[test]
    fn test_symmetry() {
        // C(-x) = -C(x)
        let field = vec![1.0, 2.0, 5.0];
        let neg_field: Vec<f64> = field.iter().map(|&x| -x).collect();
        
        let c_pos = C(&field);
        let c_neg = C(&neg_field);
        
        for (pos, neg) in c_pos.iter().zip(c_neg.iter()) {
            assert!((pos + neg).abs() < 1e-10,
                "Symmetry violated: C(-x) ≠ -C(x)");
        }
    }

    #[test]
    fn test_sign_preservation() {
        let field = vec![5.0, -3.0, 0.0, 10.0, -0.5];
        let result = C(&field);
        
        for (x, c_x) in field.iter().zip(result.iter()) {
            if x.abs() > 1e-10 {
                assert!(x.signum() == c_x.signum(),
                    "Sign not preserved: {} -> {}", x, c_x);
            }
        }
    }

    #[test]
    fn test_monotonicity() {
        // If |x| < |y|, then |C(x)| < |C(y)|
        let x = 2.0;
        let y = 5.0;
        
        let c_x = C(&vec![x])[0];
        let c_y = C(&vec![y])[0];
        
        assert!(c_x.abs() < c_y.abs(),
            "Monotonicity violated: |C({})| = {} >= |C({})| = {}",
            x, c_x.abs(), y, c_y.abs());
    }
}
