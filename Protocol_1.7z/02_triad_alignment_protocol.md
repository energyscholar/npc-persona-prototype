# Triad Alignment Protocol
## Purpose‑Centered Human–AI Development

**Audience:** Internal engineers, AI collaborators, partners

**Use of this document**  
This document defines the *non‑negotiable structural discipline* by which we build systems with humans and AI.

It exists to:
- align people and AI around purpose **before** code exists
- preserve meaning under acceleration
- prevent compensation‑driven development
- make structural correctness teachable

This is not a workflow preference.  
It is a coherence‑preserving discipline.

---

## What This Is / What This Is Not

**What this is not**  
This protocol is not Agile, TDD, code review, or a generic productivity framework.  
It does not *begin* by prescribing tools, languages, or architectures.

**What this is**  
It is a role‑separated alignment discipline designed to preserve purpose and structure under acceleration.

Tooling, languages, and architectures are selected *only insofar as they satisfy the structural constraints imposed by the protocol*.  
Tools that cannot support those constraints are naturally excluded.

---

## 1. Core Principle

> **Purpose precedes structure. Structure precedes code.**

When this order is violated, systems drift while appearing productive.

The Triad exists to enforce this ordering under conditions of speed, volume, and complexity.

---

## 2. The Triad (Irreducible Roles)

The system consists of **three asymmetric roles**. None may be merged.

Merging roles collapses information asymmetry and re‑introduces compensation, even when done by highly skilled individuals.

---

### 1. Human — Purpose & Project Origin (Executive Role)

**Role:** Source of meaning and direction

Responsibilities:
- define *why* the system exists
- define what the system is in service of
- define what must never be optimized away
- establish project boundaries and success criteria
- establish governing structural and mathematical constraints
- initiate alignment checks and resets

**Produces:**
- purpose statements
- project definitions
- invariants and constraints

This role does **not** optimize and does **not** code.

---

### 2. LLM — Coding Primary

**Role:** Structural generator

Responsibilities:
- generate implementations constrained by agreed structure
- collapse patterns and redundancy
- implement only what is requested

Restrictions:
- does not invent tests
- does not redefine purpose
- does not interpret test results
- does not receive raw test output or stack traces

**Receives:**
- structural constraints
- auditor prompts

**Produces:**
- code artifacts

---

### 3. LLM — Auditor / Tester

**Role:** Structural verifier

Responsibilities:
- encode invariants as tests
- execute tests and observe behavior
- interpret failures structurally

Restrictions:
- does not modify code
- does not reason about full implementations
- does not reinterpret purpose

Allowed exception:
- may provide *minimal, targeted* code examples **only** to clarify a specific invariant violation

**Receives:**
- code artifacts (for execution only)

**Produces:**
- test results
- structured prompts describing what must change

---

## 3. Directional Information Flow

Information flows **forward only**:

**Purpose → Structure → Code → Behavior → Interpretation → Prompt → Code**

There is no sideways or backward flow:
- coders never see raw failures
- auditors never fix code
- humans never arbitrate implementation details

This preserves antisymmetry and prevents collapse.

---

## 4. Mathematical Alignment (Required Before Coding)

No coding begins without alignment.

Alignment means shared agreement on:
- governing structure
- invariants that must hold
- valid versus compensatory behavior
- expected failure modes when structure is missing

Alignment is established by reasoning about behavior **without reference to implementation**.

---

## 5. Alignment Maintenance & Drift Detection

Alignment must be checked repeatedly, especially during:
- testing
- debugging
- optimization
- refactoring

**Drift signals include:**
- code altered to satisfy tests
- tests altered to accommodate code
- increasing local consistency with decreasing meaning

**Example failure mode:**  
A solver begins with structural invariants, but repeated test failures lead to added conditionals and tuning parameters.  
Tests pass. Behavior degrades. Meaning is lost.  
This is drift.

When drift appears, coding stops.

The response is an **alignment check**, not a fix.

---

## 6. The Alignment Check

Ask:
- What is this system in service of?
- Which invariant is being enforced?
- Are we restoring structure or adding compensation?
- Would removing this test expose missing structure or violate purpose?

If answers are unclear, work pauses.

---

## 7. Acceleration and Human Placement

LLM acceleration produces code volume faster than humans can review.

Therefore:
- humans do **not** read all code
- humans operate at the structural layer
- details are entered only when a specific invariant fails

Exhaustive review under acceleration is a category error.

---

## 8. Teaching by Embodiment

The Triad is learned primarily through observation.

Leads demonstrate:
- when generation proceeds
- when alignment checks are invoked
- when work pauses
- when reset replaces patching

Authority is structural, not personal.

---

## 9. Final Statement

> **The Triad is not a process. It is a boundary condition.**

It exists to ensure that speed never outruns meaning, and that power never outruns purpose.

This document defines how that invariant is protected.

